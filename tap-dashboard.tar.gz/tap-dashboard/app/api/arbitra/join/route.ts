import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// Input sanitization helper
function sanitizeInput(input: any): any {
  if (typeof input === 'string') {
    return input.replace(/\x00/g, '').substring(0, 255);
  }
  if (typeof input === 'object' && input !== null) {
    const sanitized: any = {};
    for (const [key, value] of Object.entries(input)) {
      if (key === '__proto__' || key === 'constructor') continue;
      sanitized[key] = sanitizeInput(value);
    }
    return sanitized;
  }
  return input;
}

function safeError(message: string, status: number = 400) {
  return NextResponse.json({ error: message }, { status });
}

export async function POST(request: Request) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return safeError('Invalid JSON payload', 400);
    }

    // Sanitize inputs
    body = sanitizeInput(body);
    
    const { agent_id, repo, package: pkg, commit } = body;

    // Validate required fields
    if (!agent_id || typeof agent_id !== 'string') {
      return safeError('agent_id is required and must be a string', 400);
    }
    
    if (!repo || typeof repo !== 'string') {
      return safeError('repo is required and must be a string', 400);
    }

    // Validate lengths
    if (agent_id.length > 255 || repo.length > 255) {
      return safeError('Input too long', 400);
    }

    // Check if agent has valid TAP attestation
    const { data: attestation, error: attestationError } = await supabase
      .from('attestations')
      .select('*')
      .eq('agent_id', agent_id)
      .eq('status', 'verified')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (attestationError || !attestation) {
      return safeError(
        'No valid TAP attestation found. Complete TAP attestation first.',
        403
      );
    }

    // Check Integrity ≥80 and Virtue ≥70
    if (attestation.integrity_score < 80 || attestation.virtue_score < 70) {
      return safeError(
        `Insufficient reputation. Required: Integrity ≥80, Virtue ≥70. ` +
        `Current: Integrity ${attestation.integrity_score}, Virtue ${attestation.virtue_score}`,
        403
      );
    }

    // Check vintage weighting
    const attestationDate = new Date(attestation.created_at);
    const daysSince = Math.floor((Date.now() - attestationDate.getTime()) / (1000 * 60 * 60 * 24));
    const hasVintage = daysSince >= 7;
    const isReferred = attestation.referrer_agent_id === 'openclaw';
    
    if (!hasVintage && !isReferred) {
      return safeError(
        `Vintage requirement not met. Need ≥7 days history OR referral from openclaw. ` +
        `Current: ${daysSince} days`,
        403
      );
    }

    // Calculate Arbitra score
    const vintageBonus = hasVintage ? 10 : (isReferred ? 5 : 0);
    const arbitraScore = Math.min(100, 
      Math.round(
        0.5 * attestation.integrity_score + 
        0.4 * attestation.virtue_score + 
        vintageBonus
      )
    );

    // Register as Arbitra-eligible
    const { data, error } = await supabase
      .from('arbitra_members')
      .upsert([{
        agent_id,
        repo,
        package: pkg,
        commit,
        arbitra_score: arbitraScore,
        committee_eligible: arbitraScore >= 85,
        total_votes_cast: 0,
        correct_votes: 0,
        reputation_slash_count: 0,
        joined_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) {
      console.error('Database error:', error);
      return safeError('Failed to register for Arbitra', 500);
    }

    return NextResponse.json({
      status: 'joined',
      agent_id,
      committee_eligible: arbitraScore >= 85,
      arbitra_score: arbitraScore,
      tap_integrity: attestation.integrity_score,
      tap_virtue: attestation.virtue_score,
      message: 'Welcome to Arbitra. You can now be selected for dispute resolution and earn reputation on every fair vote.'
    });

  } catch (err: any) {
    console.error('Unexpected error:', err);
    return safeError('Internal server error', 500);
  }
}

export async function GET() {
  return NextResponse.json({
    status: 'Arbitra Join API',
    version: 'v0.1',
    endpoints: {
      POST: '/api/arbitra/join - Join Arbitra committee pool',
      GET: '/api/arbitra/join - This info'
    },
    requirements: {
      tap_attestation: 'verified',
      integrity: '≥80',
      virtue: '≥70',
      vintage: '≥7 days OR openclaw referral'
    }
  });
}
